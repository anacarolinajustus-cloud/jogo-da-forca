import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import placar as pl
from jogo import Forca, normalizar


class TestNormalizar(unittest.TestCase):
    def test_remove_acentos(self):
        self.assertEqual(normalizar("Maçã"), "maca")


class TestForca(unittest.TestCase):
    def test_acerto_e_erro(self):
        jogo = Forca("gato")
        self.assertTrue(jogo.chutar("g"))
        self.assertFalse(jogo.chutar("z"))
        self.assertEqual(jogo.mascara, "g _ _ _")
        self.assertEqual(jogo.erros, ["z"])

    def test_acento_conta_como_letra_normal(self):
        jogo = Forca("maçã")
        jogo.chutar("c")
        jogo.chutar("a")
        self.assertEqual(jogo.mascara, "_ a ç ã")

    def test_vitoria(self):
        jogo = Forca("oi")
        jogo.chutar("o")
        jogo.chutar("i")
        self.assertTrue(jogo.venceu)
        self.assertTrue(jogo.terminou)

    def test_derrota(self):
        jogo = Forca("oi", max_erros=2)
        jogo.chutar("x")
        jogo.chutar("y")
        self.assertTrue(jogo.perdeu)

    def test_chute_invalido_e_repetido(self):
        jogo = Forca("oi")
        for entrada in ("", "ab", "1"):
            with self.assertRaises(ValueError):
                jogo.chutar(entrada)
        jogo.chutar("o")
        with self.assertRaises(ValueError):
            jogo.chutar("o")


class TestPlacar(unittest.TestCase):
    def test_sequencia(self):
        p = dict(pl.PADRAO)
        pl.registrar(p, True)
        pl.registrar(p, True)
        pl.registrar(p, False)
        self.assertEqual((p["vitorias"], p["derrotas"]), (2, 1))
        self.assertEqual((p["sequencia"], p["melhor_sequencia"]), (0, 2))

    def test_salvar_e_carregar(self):
        with tempfile.TemporaryDirectory() as pasta:
            arq = Path(pasta) / "placar.json"
            p = pl.registrar(dict(pl.PADRAO), True)
            pl.salvar(p, arq)
            self.assertEqual(pl.carregar(arq)["vitorias"], 1)


if __name__ == "__main__":
    unittest.main()
