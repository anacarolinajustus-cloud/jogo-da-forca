# 🎮 Jogo da Forca

Jogo da forca para o terminal, feito em Python puro (sem dependências externas).

## ✨ Funcionalidades

- 4 categorias de palavras (Programação, Animais, Frutas, Países) + modo aleatório
- Aceita letras com ou sem acento (`a` acerta `ã`, `á`, `â`...)
- Desenho ASCII da forca que evolui a cada erro
- Placar salvo em arquivo (vitórias, derrotas e melhor sequência)
- Lógica separada da interface e coberta por testes

## 🚀 Como jogar

Requer Python 3.9+.

```bash
git clone https://github.com/SEU-USUARIO/jogo-da-forca.git
cd jogo-da-forca
python main.py
```

## 🧪 Rodando os testes

```bash
python -m unittest discover -s tests -v
```

## 📁 Estrutura

```
jogo-da-forca/
├── main.py          # interface do terminal e loop do jogo
├── jogo.py          # lógica da forca (classe Forca)
├── palavras.py      # banco de palavras por categoria
├── placar.py        # leitura/gravação do placar em JSON
└── tests/
    └── test_jogo.py
```

## 🔧 Ideias para evoluir

- [ ] Níveis de dificuldade (menos tentativas)
- [ ] Modo de 2 jogadores
- [ ] Dicas (revelar uma letra por um custo)
- [ ] Carregar palavras de um arquivo externo

## 📄 Licença

MIT
