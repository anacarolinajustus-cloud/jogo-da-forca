"""Jogo da Forca no terminal. Execute: python main.py"""
import random

import placar as pl
from jogo import Forca
from palavras import PALAVRAS

FORCA_ASCII = [
    """
      +---+
      |   |
          |
          |
          |
          |
    =========""",
    """
      +---+
      |   |
      O   |
          |
          |
          |
    =========""",
    """
      +---+
      |   |
      O   |
      |   |
          |
          |
    =========""",
    """
      +---+
      |   |
      O   |
     /|   |
          |
          |
    =========""",
    """
      +---+
      |   |
      O   |
     /|\\  |
          |
          |
    =========""",
    """
      +---+
      |   |
      O   |
     /|\\  |
     /    |
          |
    =========""",
    """
      +---+
      |   |
      O   |
     /|\\  |
     / \\  |
          |
    =========""",
]


def escolher_categoria() -> tuple[str, str]:
    categorias = list(PALAVRAS)
    print("\nEscolha uma categoria:")
    for i, nome in enumerate(categorias, 1):
        print(f"  {i}) {nome}")
    print("  0) Aleatória")

    while True:
        opcao = input("> ").strip()
        if opcao == "0":
            nome = random.choice(categorias)
            break
        if opcao.isdigit() and 1 <= int(opcao) <= len(categorias):
            nome = categorias[int(opcao) - 1]
            break
        print("Opção inválida, tente de novo.")
    return nome, random.choice(PALAVRAS[nome])


def jogar_partida(placar: dict) -> None:
    categoria, palavra = escolher_categoria()
    jogo = Forca(palavra)

    while not jogo.terminou:
        print(FORCA_ASCII[len(jogo.erros)])
        print(f"\nCategoria: {categoria}")
        print(f"Palavra:   {jogo.mascara}")
        print(f"Erros:     {', '.join(jogo.erros) or '-'}  "
              f"({jogo.tentativas_restantes} tentativas restantes)")

        try:
            acertou = jogo.chutar(input("\nSua letra: "))
        except ValueError as erro:
            print(f"⚠️  {erro}")
            continue
        print("✅ Acertou!" if acertou else "❌ Errou!")

    print(FORCA_ASCII[len(jogo.erros)])
    if jogo.venceu:
        print(f"\n🎉 Você venceu! A palavra era '{jogo.palavra}'.")
    else:
        print(f"\n💀 Fim de jogo! A palavra era '{jogo.palavra}'.")

    pl.registrar(placar, jogo.venceu)
    pl.salvar(placar)


def mostrar_placar(placar: dict) -> None:
    print(
        f"\n🏆 Placar: {placar['vitorias']} vitórias | {placar['derrotas']} derrotas | "
        f"sequência atual: {placar['sequencia']} | melhor: {placar['melhor_sequencia']}"
    )


def main() -> None:
    print("=" * 40)
    print("        🎮  JOGO DA FORCA  🎮")
    print("=" * 40)
    placar = pl.carregar()

    while True:
        mostrar_placar(placar)
        jogar_partida(placar)
        mostrar_placar(placar)
        if input("\nJogar de novo? (s/n): ").strip().lower() != "s":
            print("Até a próxima! 👋")
            break


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nJogo encerrado. Até a próxima! 👋")
