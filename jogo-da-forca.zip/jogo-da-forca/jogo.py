"""Lógica pura do jogo da forca (sem input/print), fácil de testar."""
import unicodedata

MAX_ERROS = 6


def normalizar(texto: str) -> str:
    """Remove acentos e coloca em minúsculas: 'Maçã' -> 'maca'."""
    sem_acento = unicodedata.normalize("NFD", texto)
    sem_acento = "".join(c for c in sem_acento if unicodedata.category(c) != "Mn")
    return sem_acento.lower()


class Forca:
    def __init__(self, palavra: str, max_erros: int = MAX_ERROS):
        self.palavra = palavra.lower()
        self._chave = normalizar(self.palavra)
        self.max_erros = max_erros
        self.acertos: set[str] = set()
        self.erros: list[str] = []

    def chutar(self, letra: str) -> bool:
        """Registra um chute. Retorna True se acertou, False se errou.

        Levanta ValueError se o chute for inválido ou repetido.
        """
        letra = normalizar(letra.strip())
        if len(letra) != 1 or not letra.isalpha():
            raise ValueError("Digite apenas UMA letra.")
        if letra in self.acertos or letra in self.erros:
            raise ValueError(f"Você já tentou a letra '{letra}'.")

        if letra in self._chave:
            self.acertos.add(letra)
            return True
        self.erros.append(letra)
        return False

    @property
    def mascara(self) -> str:
        """Palavra com '_' nas letras ainda não descobertas."""
        partes = []
        for original, chave in zip(self.palavra, self._chave):
            if not original.isalpha() or chave in self.acertos:
                partes.append(original)
            else:
                partes.append("_")
        return " ".join(partes)

    @property
    def tentativas_restantes(self) -> int:
        return self.max_erros - len(self.erros)

    @property
    def venceu(self) -> bool:
        letras = {c for c in self._chave if c.isalpha()}
        return letras <= self.acertos

    @property
    def perdeu(self) -> bool:
        return len(self.erros) >= self.max_erros

    @property
    def terminou(self) -> bool:
        return self.venceu or self.perdeu
