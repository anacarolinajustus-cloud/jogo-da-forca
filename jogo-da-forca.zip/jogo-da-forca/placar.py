"""Placar simples salvo em placar.json (ignorado pelo Git)."""
import json
from pathlib import Path

ARQUIVO = Path(__file__).with_name("placar.json")
PADRAO = {"vitorias": 0, "derrotas": 0, "sequencia": 0, "melhor_sequencia": 0}


def carregar(arquivo: Path = ARQUIVO) -> dict:
    try:
        dados = json.loads(arquivo.read_text(encoding="utf-8"))
        return {**PADRAO, **dados}
    except (FileNotFoundError, json.JSONDecodeError):
        return dict(PADRAO)


def salvar(placar: dict, arquivo: Path = ARQUIVO) -> None:
    arquivo.write_text(json.dumps(placar, indent=2), encoding="utf-8")


def registrar(placar: dict, venceu: bool) -> dict:
    if venceu:
        placar["vitorias"] += 1
        placar["sequencia"] += 1
        placar["melhor_sequencia"] = max(placar["melhor_sequencia"], placar["sequencia"])
    else:
        placar["derrotas"] += 1
        placar["sequencia"] = 0
    return placar
