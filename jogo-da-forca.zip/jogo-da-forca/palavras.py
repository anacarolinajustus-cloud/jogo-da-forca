"""Banco de palavras por categoria. Adicione as suas!"""

PALAVRAS = {
    "Programação": [
        "python", "variável", "função", "algoritmo", "repositório",
        "compilador", "biblioteca", "depuração", "recursão", "terminal",
    ],
    "Animais": [
        "elefante", "borboleta", "cachorro", "jacaré", "tamanduá",
        "golfinho", "papagaio", "camaleão", "tartaruga", "coruja",
    ],
    "Frutas": [
        "abacaxi", "morango", "maracujá", "melancia", "goiaba",
        "framboesa", "tangerina", "jabuticaba", "acerola", "pitaya",
    ],
    "Países": [
        "brasil", "argentina", "portugal", "japão", "egito",
        "canadá", "alemanha", "austrália", "méxico", "noruega",
    ],
}
